public class Quotation {
  String quote = "«Я не проиграл. Я только что нашел 10 000 способов, которые не работают».";
  public void display() {
    System.out.println(quote);
  }
}